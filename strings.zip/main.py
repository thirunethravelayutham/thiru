print("thirunethra")

name="thirunethra"
print(name[0:4])

name="thiru"
print(name[3])

name="4444"
print(type(name))

a=5
b=4
c=a+b
print(c)
d=a-b
print(d)
e=a*b
print(e)
f=a/b
print(f)
g=a//b
print(g)
h=a%b 
print(h)


