d={"abc":1,"xyz":4}
print(d["abc"])

d={"abc":1,"abc":4}
print(d["abc"])

d={"abc":1,"xyz":1}
print(d["abc"])

dataset={"name":"abc","age":5,(1,3):{2,3}}
a=dataset.keys()
print(a)

dataset={"name":"abc","age":5,(1,3):{2,3}}
a=dataset.items()
print(a)

dataset={"name":"abc","age":5,(1,3):{2,3}}
a=dataset.values()
print(a)

dataset={"name":"abc","age":5,(1,3):{2,3}}
dataset.pop("age")
print(dataset)

dataset={"name":"abc","age":5,(1,3):{2,3}}
dataset.popitem()
print(dataset)
