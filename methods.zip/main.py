#methods
name="thirunethra"
a=name.upper()
print(a)


name="THIRUNETHRA"
b=name.lower()
print(b)


name="THIRUNETHRA"
c=name.isupper()
print(c)


name="thirunethra"
d=name.islower()
print(d)


name="thirunethra"
print(name[0:5:2])


name="thirunethra"
e=name.capitalize()
print(e)



