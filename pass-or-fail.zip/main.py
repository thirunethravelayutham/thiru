n=int(input("enter your mark:"))
if n>30 and n<70:
    print("pass")
    print("need more improvement")
elif n>70:
    print("pass")
    print("well and good")
else:
    print("fail")