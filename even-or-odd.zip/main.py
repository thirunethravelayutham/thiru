b=10
if (b%2==0):
    print("the given number is even")
else:
    print("the given number is odd")