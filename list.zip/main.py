#finding index
name='thirunethra'
a=name.index('n')
print(a)

name='thirunethra'
a=name.index('run')
print(a)

name='Thirunethra'
a=name.swapcase()
print(a)

name='thirunethra'
a=name.startswith('a')
print(a)

name='thirunethra'
a=name.endswith('a')
print(a)

#collection list
l=[1.4,5,'thiru','dance']
print(l)

l=[1.4,5,'thiru','dance']
l[1]='a'
print(l)

l=[1.4,5,'thiru','dance']
l[1]='a'
print(l[0:2])

l=[1.4,5,'thiru','dance']
print(l[0:3:2])

l=[1.4,5,'thiru','dance']
print(len(l))

l=[1.4,5,'thiru','dance']
l.append(7)
l.insert(2,'a')
print(l)
