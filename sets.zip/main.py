#tuple
t=(1,2,3,13.9,'thiru')
print(t)

#type
t=(1)
print(type(t))

t=(1,2)
print(type(t))

#collection set
s={1,2,3,4,4,6}
print(s)

s={'a','b','c'}
print(s)

s={1,3,4,4,'a','b'}
print(s)

#add
s={1,3,4,5,4}
s.add(2)
print(s)

#remove
s={1,2,3,4,7}
s.remove(7)
print(s)

#add and remove
s={1,2,3,4,4,6}
s.add('thiru')
s.remove(4)
print(s)

#discard
s={1,2,3,4,4,5,6,6}
s.discard(6)
print(s)

#union
s={1,2,3,4,4}
s1={'b','c','d'}
print(s.union(s1))

#intersection
s={1,2,3,4,5}
s1={1,'thiru',2,'b',5}
print(s.intersection(s1))

#update
s={1,2,3,4,5,5}
s1={'c','b','a'}
s.update(s1)
print(s)