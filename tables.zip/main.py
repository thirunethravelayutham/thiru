num=int(input("Enter a number:"))
if (num%5==0):
    print("multiple")
else:
    print("not multiple")